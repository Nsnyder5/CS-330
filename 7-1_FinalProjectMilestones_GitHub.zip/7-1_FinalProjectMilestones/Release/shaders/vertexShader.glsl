/***************************************************************
**
** CS 330 Final Project
**
** Nicole Snyder
** Southern New Hampshire University
** CS-330-11679-M01 Computational Graphics and Visualization
** Dr. Vivian Lyon
** October 13, 2026
**
** File: vertexShader.glsl
** Purpose: Transforms final-project vertices, normals, and texture coordinates into view and projection space.
**
** Student Modification Note:
** This project uses the SNHU course starter framework. Original
** instructor attribution is preserved below when present. Student
** additions and modifications are documented with descriptive
** comments so another programmer can follow the implemented logic.
**
** Reference:
** Snyder, N. (2026). CS 330 Final Project.
** Southern New Hampshire University.
**
****************************************************************/
#version 330 core
layout (location = 0) in vec3 inVertexPosition;
layout (location = 1) in vec3 inVertexNormal;
layout (location = 2) in vec2 inTextureCoordinate;

out vec3 fragmentPosition;
out vec3 fragmentVertexNormal;
out vec2 fragmentTextureCoordinate;

uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
   fragmentPosition = vec3(model * vec4(inVertexPosition, 1.0));
   gl_Position = projection * view * model * vec4(inVertexPosition, 1.0f);
   // Transform normals with the inverse-transpose model matrix so lighting
   // remains correct after non-uniform scaling and rotation.
   fragmentVertexNormal = normalize(mat3(transpose(inverse(model))) * inVertexNormal);
   fragmentTextureCoordinate = inTextureCoordinate;
}