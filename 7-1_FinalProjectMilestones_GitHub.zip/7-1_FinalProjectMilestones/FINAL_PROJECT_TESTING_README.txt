CS 330 Final Project - Testing Guide
Nicole Snyder
October 13, 2026

PROJECT TO OPEN
Projects\7-1_FinalProjectMilestones\7-1_FinalProjectMilestones.sln

VISUAL STUDIO
1. Open the solution in Visual Studio 2022.
2. Select Release and x86.
3. Build > Rebuild Solution.
4. Run with Local Windows Debugger.
5. After a successful Release build, the EXE should be created in the project's Release folder.

EXPECTED FINAL SCENE
- Textured wooden desktop plane
- Multi-part gold desk lamp with stainless underside
- Closed blue notebook with page block
- Textured metallic mug with torus handle
- Textured pencil cup containing two pencils
- Warm lamp spotlight plus cool and neutral point-light fills

CONTROLS
W / S    Move forward / backward
A / D    Move left / right
Q / E    Move up / down
Mouse    Change camera yaw and pitch
Wheel    Adjust camera movement speed
M        Toggle perspective / orthographic projection
P        Force perspective projection
O        Force orthographic projection
Esc      Close the application

RUBRIC FEATURES TO VERIFY
- At least four completed objects are visible.
- At least four primitive types appear (box, cone, cylinder, plane, sphere, torus).
- Lamp is a reusable complex object made from multiple primitives.
- Multiple 1024px+ textures are used with UV scaling adjusted to preserve proportions and reduce visible repetition.
- Spotlight and point lights illuminate the full arrangement.
- WASD + QE navigation works.
- Mouse pitch/yaw and mouse-wheel speed control work.
- M switches projections without changing the camera orientation.
