/***************************************************************
**
** CS 330 Final Project
**
** Nicole Snyder
** Southern New Hampshire University
** CS-330-11679-M01 Computational Graphics and Visualization
** Dr. Vivian Lyon
** October 13, 2026
**
** File: SceneManager.cpp
** Purpose: Prepares textures, materials, lighting, and modular rendering functions for the completed final 3D desktop scene.
**
** Student Modification Note:
** This project uses the SNHU course starter framework. Original
** instructor attribution is preserved below when present. Student
** additions and modifications are documented with descriptive
** comments so another programmer can follow the implemented logic.
**
** Reference:
** Snyder, N. (2026). CS 330 Final Project.
** Southern New Hampshire University.
**
****************************************************************/
///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////


#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Initialize the texture collection before any texture files are loaded.
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "\0";
		m_textureIDs[i].ID = 0;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;

	// Release the texture objects that were allocated for the scene.
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		if (m_textureIDs[i].ID != 0)
		{
			glDeleteTextures(1, &m_textureIDs[i].ID);
			m_textureIDs[i].ID = 0;
		}
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  DefineObjectMaterials()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Defines reusable Phong material profiles for the desk,
 *  lamp, notebook, mug, and pencil-cup objects.
 *  Parameters: None.
 *  Returns: void.
 *  Student changes: Expands the milestone materials so each final
 *  project object has a deliberate diffuse/specular response.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.78f, 0.72f, 0.65f);
	woodMaterial.specularColor = glm::vec3(0.22f, 0.20f, 0.18f);
	woodMaterial.shininess = 16.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL goldMaterial;
	goldMaterial.diffuseColor = glm::vec3(0.92f, 0.78f, 0.42f);
	goldMaterial.specularColor = glm::vec3(0.90f, 0.82f, 0.55f);
	goldMaterial.shininess = 64.0f;
	goldMaterial.tag = "gold";
	m_objectMaterials.push_back(goldMaterial);

	OBJECT_MATERIAL brushedGoldMaterial;
	brushedGoldMaterial.diffuseColor = glm::vec3(0.82f, 0.72f, 0.48f);
	brushedGoldMaterial.specularColor = glm::vec3(0.72f, 0.68f, 0.54f);
	brushedGoldMaterial.shininess = 42.0f;
	brushedGoldMaterial.tag = "brushedGold";
	m_objectMaterials.push_back(brushedGoldMaterial);

	OBJECT_MATERIAL steelMaterial;
	steelMaterial.diffuseColor = glm::vec3(0.76f, 0.79f, 0.82f);
	steelMaterial.specularColor = glm::vec3(0.96f, 0.96f, 0.96f);
	steelMaterial.shininess = 96.0f;
	steelMaterial.tag = "steel";
	m_objectMaterials.push_back(steelMaterial);

	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.diffuseColor = glm::vec3(0.78f, 0.80f, 0.84f);
	ceramicMaterial.specularColor = glm::vec3(0.70f, 0.72f, 0.76f);
	ceramicMaterial.shininess = 52.0f;
	ceramicMaterial.tag = "ceramic";
	m_objectMaterials.push_back(ceramicMaterial);

	OBJECT_MATERIAL notebookMaterial;
	notebookMaterial.diffuseColor = glm::vec3(0.20f, 0.28f, 0.42f);
	notebookMaterial.specularColor = glm::vec3(0.18f, 0.20f, 0.24f);
	notebookMaterial.shininess = 24.0f;
	notebookMaterial.tag = "notebook";
	m_objectMaterials.push_back(notebookMaterial);

	OBJECT_MATERIAL paperMaterial;
	paperMaterial.diffuseColor = glm::vec3(0.92f, 0.90f, 0.84f);
	paperMaterial.specularColor = glm::vec3(0.10f, 0.10f, 0.10f);
	paperMaterial.shininess = 8.0f;
	paperMaterial.tag = "paper";
	m_objectMaterials.push_back(paperMaterial);

	OBJECT_MATERIAL pencilMaterial;
	pencilMaterial.diffuseColor = glm::vec3(0.92f, 0.62f, 0.16f);
	pencilMaterial.specularColor = glm::vec3(0.18f, 0.16f, 0.12f);
	pencilMaterial.shininess = 18.0f;
	pencilMaterial.tag = "pencil";
	m_objectMaterials.push_back(pencilMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Configures a warm lamp spotlight and two point-light
 *  fills so all final-project objects remain readable from multiple
 *  camera angles while preserving a focused desk-lamp appearance.
 *  Parameters: None.
 *  Returns: void.
 *  Student changes: Uses multiple light types/colors and all Phong
 *  ambient, diffuse, and specular components required by the rubric.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Enable Phong lighting in the fragment shader.
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// Disable all available lights before selectively enabling the final setup.
	m_pShaderManager->setBoolValue("directionalLight.bActive", false);
	for (int i = 0; i < 5; i++)
	{
		std::string lightName = "pointLights[" + std::to_string(i) + "].bActive";
		m_pShaderManager->setBoolValue(lightName.c_str(), false);
	}
	m_pShaderManager->setBoolValue("spotLight.bActive", false);

	// Primary warm spotlight: located under the lamp head and aimed at the desk.
	m_pShaderManager->setVec3Value("spotLight.position", -1.20f, 3.65f, 0.35f);
	m_pShaderManager->setVec3Value("spotLight.direction", 0.10f, -1.0f, -0.08f);
	m_pShaderManager->setFloatValue("spotLight.cutOff", glm::cos(glm::radians(18.0f)));
	m_pShaderManager->setFloatValue("spotLight.outerCutOff", glm::cos(glm::radians(30.0f)));
	m_pShaderManager->setFloatValue("spotLight.constant", 1.0f);
	m_pShaderManager->setFloatValue("spotLight.linear", 0.09f);
	m_pShaderManager->setFloatValue("spotLight.quadratic", 0.032f);
	m_pShaderManager->setVec3Value("spotLight.ambient", 0.10f, 0.075f, 0.045f);
	m_pShaderManager->setVec3Value("spotLight.diffuse", 1.00f, 0.82f, 0.56f);
	m_pShaderManager->setVec3Value("spotLight.specular", 1.00f, 0.92f, 0.72f);
	m_pShaderManager->setBoolValue("spotLight.bActive", true);

	// Colored cool fill: adds blue-gray separation to the lamp and right side.
	m_pShaderManager->setVec3Value("pointLights[0].position", 4.8f, 5.3f, 4.2f);
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.050f, 0.060f, 0.090f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.34f, 0.44f, 0.68f);
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.46f, 0.58f, 0.78f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// Soft neutral fill: prevents the mug/notebook side from disappearing in shadow.
	m_pShaderManager->setVec3Value("pointLights[1].position", -4.5f, 3.8f, 3.2f);
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.045f, 0.040f, 0.035f);
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.22f, 0.20f, 0.18f);
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.24f, 0.23f, 0.22f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);
}

/***********************************************************
 *  PrepareScene()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Loads final-project textures and meshes, defines materials,
 *  and configures lights once before the render loop begins.
 *  Parameters: None.
 *  Returns: void.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	DefineObjectMaterials();
	SetupSceneLights();

	// All final textures meet or exceed the assignment's 1024-pixel requirement.
	CreateGLTexture("textures/rusticwood.jpg", "deskWood");
	CreateGLTexture("textures/gold-seamless-texture.jpg", "lampGold");
	CreateGLTexture("textures/circular-brushed-gold-texture.jpg", "brushedGold");
	CreateGLTexture("textures/stainless.jpg", "lightPanel");
	BindGLTextures();

	// Load each primitive once and reuse it through the object rendering functions.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadTorusMesh(0.22f);
}

/***********************************************************
 *  RenderDeskSurface()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Draws the large textured work surface that visually
 *  anchors the final desktop arrangement.
 *  Parameters: None.
 *  Returns: void.
 ***********************************************************/
void SceneManager::RenderDeskSurface()
{
	SetTransformations(glm::vec3(10.0f, 1.0f, 8.0f),
		0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 0.0f, 0.0f));
	SetShaderTexture("deskWood");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("wood");
	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderDeskLamp()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Draws the reusable multi-primitive desk lamp using
 *  cylinders, a sphere, and boxes with coordinated metal textures.
 *  Parameters: None.
 *  Returns: void.
 ***********************************************************/
void SceneManager::RenderDeskLamp()
{
	// Base sides.
	SetTransformations(glm::vec3(0.70f, 0.18f, 0.70f),
		0.0f, 0.0f, 0.0f, glm::vec3(1.00f, 0.02f, 0.0f));
	SetShaderTexture("lampGold");
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderMaterial("gold");
	m_basicMeshes->DrawCylinderMesh(false, false, true);

	// Base caps use a radial brushed-metal texture for texture continuity.
	SetShaderTexture("brushedGold");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("brushedGold");
	m_basicMeshes->DrawCylinderMesh(true, true, false);

	// Vertical support.
	SetTransformations(glm::vec3(0.09f, 3.25f, 0.09f),
		0.0f, 0.0f, 0.0f, glm::vec3(1.00f, 0.20f, 0.0f));
	SetShaderTexture("lampGold");
	SetTextureUVScale(1.0f, 4.0f);
	SetShaderMaterial("gold");
	m_basicMeshes->DrawCylinderMesh();

	// Spherical hinge.
	SetTransformations(glm::vec3(0.18f, 0.18f, 0.18f),
		0.0f, 0.0f, 0.0f, glm::vec3(1.00f, 3.45f, 0.0f));
	SetShaderTexture("brushedGold");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("brushedGold");
	m_basicMeshes->DrawSphereMesh();

	// Angled lamp housing. UV tiling prevents the gold image from stretching.
	SetTransformations(glm::vec3(3.60f, 0.14f, 0.22f),
		0.0f, 0.0f, -12.0f, glm::vec3(-0.76f, 3.82f, 0.0f));
	SetShaderTexture("lampGold");
	SetTextureUVScale(4.0f, 1.0f);
	SetShaderMaterial("gold");
	m_basicMeshes->DrawBoxMesh();

	// Stainless light panel visually separates the underside from the housing.
	SetTransformations(glm::vec3(3.20f, 0.045f, 0.16f),
		0.0f, 0.0f, -12.0f, glm::vec3(-0.82f, 3.72f, 0.13f));
	SetShaderTexture("lightPanel");
	SetTextureUVScale(3.0f, 1.0f);
	SetShaderMaterial("steel");
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderNotebook()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Draws a low-poly closed notebook from stacked box
 *  primitives so the cover and page block remain visually distinct.
 *  Parameters: None.
 *  Returns: void.
 ***********************************************************/
void SceneManager::RenderNotebook()
{
	// Dark blue cover.
	SetTransformations(glm::vec3(2.30f, 0.10f, 1.45f),
		0.0f, -8.0f, 0.0f, glm::vec3(-0.70f, 0.05f, -1.65f));
	SetShaderColor(0.10f, 0.18f, 0.34f, 1.0f);
	SetShaderMaterial("notebook");
	m_basicMeshes->DrawBoxMesh();

	// Slightly smaller page block placed above the cover.
	SetTransformations(glm::vec3(2.12f, 0.075f, 1.30f),
		0.0f, -8.0f, 0.0f, glm::vec3(-0.70f, 0.155f, -1.65f));
	SetShaderColor(0.93f, 0.90f, 0.82f, 1.0f);
	SetShaderMaterial("paper");
	m_basicMeshes->DrawBoxMesh();

	// Narrow top strip suggests the upper cover and adds depth to the silhouette.
	SetTransformations(glm::vec3(2.30f, 0.055f, 1.45f),
		0.0f, -8.0f, 0.0f, glm::vec3(-0.70f, 0.235f, -1.65f));
	SetShaderColor(0.12f, 0.22f, 0.42f, 1.0f);
	SetShaderMaterial("notebook");
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  RenderMug()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Draws a metallic mug from a textured cylinder and torus.
 *  The separate torus creates a recognizable handle while keeping the
 *  object low-poly and reusable.
 *  Parameters: None.
 *  Returns: void.
 ***********************************************************/
void SceneManager::RenderMug()
{
	// Textured cylindrical mug body.
	SetTransformations(glm::vec3(0.62f, 1.10f, 0.62f),
		0.0f, 0.0f, 0.0f, glm::vec3(-3.05f, 0.03f, 0.65f));
	SetShaderTexture("lightPanel");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawCylinderMesh();

	// Vertical torus ring forms the mug handle. Most of the inner side is
	// naturally hidden by the mug body from common viewing angles.
	SetTransformations(glm::vec3(0.66f, 0.66f, 0.66f),
		90.0f, 0.0f, 0.0f, glm::vec3(-2.47f, 0.62f, 0.65f));
	SetShaderTexture("lightPanel");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("steel");
	m_basicMeshes->DrawTorusMesh();
}

/***********************************************************
 *  RenderPencilCup()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Draws a compact pencil cup and two pencils using a
 *  cylinder body, cylinder shafts, and cone tips. This adds another
 *  recognizable complex object while demonstrating an additional
 *  primitive type required by the project rubric.
 *  Parameters: None.
 *  Returns: void.
 ***********************************************************/
void SceneManager::RenderPencilCup()
{
	// Brushed-metal pencil cup.
	SetTransformations(glm::vec3(0.52f, 0.88f, 0.52f),
		0.0f, 0.0f, 0.0f, glm::vec3(3.15f, 0.03f, -1.15f));
	SetShaderTexture("lightPanel");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("steel");
	m_basicMeshes->DrawCylinderMesh();

	// Left pencil shaft and wooden tip.
	SetTransformations(glm::vec3(0.065f, 1.34f, 0.065f),
		0.0f, 0.0f, -5.0f, glm::vec3(2.98f, 0.58f, -1.12f));
	SetShaderColor(0.92f, 0.56f, 0.10f, 1.0f);
	SetShaderMaterial("pencil");
	m_basicMeshes->DrawCylinderMesh();

	SetTransformations(glm::vec3(0.085f, 0.24f, 0.085f),
		0.0f, 0.0f, -5.0f, glm::vec3(2.86f, 1.90f, -1.12f));
	SetShaderColor(0.74f, 0.58f, 0.38f, 1.0f);
	SetShaderMaterial("paper");
	m_basicMeshes->DrawConeMesh();

	// Right pencil uses a contrasting color and slight opposite lean.
	SetTransformations(glm::vec3(0.065f, 1.22f, 0.065f),
		0.0f, 0.0f, 6.0f, glm::vec3(3.30f, 0.58f, -1.18f));
	SetShaderColor(0.24f, 0.48f, 0.78f, 1.0f);
	SetShaderMaterial("pencil");
	m_basicMeshes->DrawCylinderMesh();

	SetTransformations(glm::vec3(0.085f, 0.24f, 0.085f),
		0.0f, 0.0f, 6.0f, glm::vec3(3.43f, 1.77f, -1.18f));
	SetShaderColor(0.74f, 0.58f, 0.38f, 1.0f);
	SetShaderMaterial("paper");
	m_basicMeshes->DrawConeMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Coordinates the reusable object-rendering functions for
 *  the completed desktop scene. Keeping each object in its own method
 *  avoids duplicated setup logic and makes the scene easier to extend.
 *  Parameters: None.
 *  Returns: void.
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderDeskSurface();
	RenderDeskLamp();
	RenderNotebook();
	RenderMug();
	RenderPencilCup();
}
