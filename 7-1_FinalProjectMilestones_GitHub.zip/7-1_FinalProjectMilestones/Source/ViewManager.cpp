/***************************************************************
**
** CS 330 Final Project
**
** Nicole Snyder
** Southern New Hampshire University
** CS-330-11679-M01 Computational Graphics and Visualization
** Dr. Vivian Lyon
** October 13, 2026
**
** File: ViewManager.cpp
** Purpose: Maintains keyboard, mouse, movement-speed, and projection controls for navigating the completed final 3D scene.
**
** Student Modification Note:
** This project uses the SNHU course starter framework. Original
** instructor attribution is preserved below when present. Student
** additions and modifications are documented with descriptive
** comments so another programmer can follow the implemented logic.
**
** Reference:
** Snyder, N. (2026). CS 330 Final Project.
** Southern New Hampshire University.
**
****************************************************************/
///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// manage the viewing of 3D objects within the viewport - camera, projection
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////


#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// Camera object used for viewing and interacting with the 3D scene.
	Camera* g_pCamera = nullptr;

	// Variables used for mouse movement processing.
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// Time between the current frame and previous frame.
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// P selects perspective, O selects orthographic, and M toggles between them.
	bool bOrthographicProjection = false;
	bool gProjectionTogglePressed = false;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// Initialize the member variables.
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;

	// Start with a perspective camera that frames the desk lamp and plane.
	// Passing yaw and pitch to Camera keeps the Front/Right/Up vectors in sync.
	g_pCamera = new Camera(
		glm::vec3(0.0f, 3.5f, 11.5f),
		glm::vec3(0.0f, 1.0f, 0.0f),
		-90.0f,
		-10.0f);
	g_pCamera->Zoom = 55.0f;
	g_pCamera->MovementSpeed = 6.0f;
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// Capture the cursor so mouse movement can continuously orbit/look around.
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// Register callbacks for nuanced mouse camera controls.
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Wheel_Callback);

	// enable blending for supporting transparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Converts cursor movement into camera yaw and pitch.
 *  Parameters: GLFW window pointer and current cursor X/Y position.
 *  Returns: void.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// Record the first event before calculating offsets so the camera does not jump.
	if (gFirstMouse)
	{
		gLastX = static_cast<float>(xMousePos);
		gLastY = static_cast<float>(yMousePos);
		gFirstMouse = false;
	}

	// Calculate cursor movement since the previous frame.
	float xOffset = static_cast<float>(xMousePos) - gLastX;
	float yOffset = gLastY - static_cast<float>(yMousePos);

	gLastX = static_cast<float>(xMousePos);
	gLastY = static_cast<float>(yMousePos);

	// Mouse movement controls yaw and pitch in either projection mode.
	// Projection changes do not change the camera orientation itself.
	if (NULL != g_pCamera)
	{
		g_pCamera->ProcessMouseMovement(xOffset, yOffset);
	}
}

/***********************************************************
 *  Mouse_Scroll_Wheel_Callback()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Adjusts camera travel speed using the mouse wheel.
 *  Parameters: GLFW window pointer and horizontal/vertical wheel offsets.
 *  Returns: void.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Wheel_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	if (NULL != g_pCamera)
	{
		g_pCamera->ProcessMouseScroll(static_cast<float>(yOffset));
	}
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Handles WASD, Q/E, escape, and projection keyboard controls.
 *  Parameters: None.
 *  Returns: void.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// Close the window if the Escape key has been pressed.
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// Stop processing navigation if the camera has not been created.
	if (NULL == g_pCamera)
	{
		return;
	}

	// Process camera zooming in and out through the scene depth.
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}

	// Process camera panning left and right.
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}

	// Process camera panning up and down.
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}

	// M performs an edge-triggered projection toggle so holding the key
	// does not cause rapid flickering between projection modes.
	if ((glfwGetKey(m_pWindow, GLFW_KEY_M) == GLFW_PRESS) &&
		(gProjectionTogglePressed == false))
	{
		bOrthographicProjection = !bOrthographicProjection;
		gProjectionTogglePressed = true;
		gFirstMouse = true;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_M) == GLFW_RELEASE)
	{
		gProjectionTogglePressed = false;
	}

	// P and O remain available as explicit perspective/orthographic shortcuts.
	if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
	{
		bOrthographicProjection = false;
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
	{
		bOrthographicProjection = true;
	}
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  Author: Nicole Snyder
 *  Date: October 13, 2026
 *  Purpose: Updates timing/input and sends the active camera view and
 *  perspective or orthographic projection matrix to the shader.
 *  Parameters: None.
 *  Returns: void.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// Per-frame timing keeps movement speed consistent across frame rates.
	float currentFrame = static_cast<float>(glfwGetTime());
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	ProcessKeyboardEvents();

	const float aspectRatio = static_cast<float>(WINDOW_WIDTH) /
		static_cast<float>(WINDOW_HEIGHT);

	// Both projection modes deliberately reuse the same camera view matrix.
	// This preserves the user's position, pitch, and yaw when switching modes.
	view = g_pCamera->GetViewMatrix();

	if (bOrthographicProjection)
	{
		// A broad orthographic volume keeps the complete desktop arrangement
		// visible while presenting parallel projection without perspective depth.
		const float orthoHalfHeight = 4.5f;
		projection = glm::ortho(
			-orthoHalfHeight * aspectRatio,
			orthoHalfHeight * aspectRatio,
			-orthoHalfHeight,
			orthoHalfHeight,
			0.1f,
			100.0f);
	}
	else
	{
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			aspectRatio,
			0.1f,
			100.0f);
	}

	// Send the active view/projection and viewer position to the shaders.
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ViewName, view);
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}
